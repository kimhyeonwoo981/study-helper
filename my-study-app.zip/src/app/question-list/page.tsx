'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';

interface Message {
  sender: 'user' | 'gpt';
  text: string;
  date?: string;
}

// 공통 함수: 저장된 키 형식과 일치시키기 위해 공백 제거
const normalizeKey = (str: string) => str.replace(/\s+/g, '');

export default function QuestionListPage() {
  const [unitMap, setUnitMap] = useState<Record<string, string[]>>({});
  const [questionCounts, setQuestionCounts] = useState<Record<string, number>>({});
  const [userQuestionsByUnit, setUserQuestionsByUnit] = useState<Record<string, Message[]>>({}); // ✅ Message[]로 변경

  useEffect(() => {
    const mapRaw = localStorage.getItem('question_unit_map');
    if (!mapRaw) return;

    const map = JSON.parse(mapRaw) as Record<string, string[]>;
    setUnitMap(map);

    const counts: Record<string, number> = {};
    const questionTexts: Record<string, Message[]> = {}; // ✅ 객체 배열로 변경

    Object.entries(map).forEach(([subject, units]) => {
      const normalizedSubject = normalizeKey(subject);

      units.forEach((unit) => {
        const key = `question_by_unit_${normalizedSubject}_${unit}`;
        try {
          const raw = localStorage.getItem(key);
          if (!raw) {
            counts[key] = 0;
            questionTexts[key] = [];
            return;
          }

          const messages: Message[] = JSON.parse(raw);
          const userMessages = messages.filter((msg) => msg.sender === 'user');
          counts[key] = userMessages.length;
          questionTexts[key] = userMessages; // ✅ 텍스트만이 아니라 전체 객체 저장
        } catch {
          counts[key] = 0;
          questionTexts[key] = [];
        }
      });
    });

    setQuestionCounts(counts);
    setUserQuestionsByUnit(questionTexts);
  }, []);

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">📘 질문 리스트</h1>

      {Object.entries(unitMap).map(([subject, units]) => (
        <div key={subject} className="border rounded p-4 mb-6">
          <div className="flex items-center justify-between mb-2">
            <h2 className="text-lg font-semibold">📚 {subject}</h2>
            <Link
              href={`/question-list/${encodeURIComponent(subject)}`}
              className="text-sm bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600"
            >
              보기
            </Link>
          </div>

          <ul className="pl-4 space-y-4">
            {units.map((unit) => {
              const normalizedSubject = normalizeKey(subject);
              const key = `question_by_unit_${normalizedSubject}_${unit}`;
              const count = questionCounts[key] || 0;
              const userQuestions = userQuestionsByUnit[key] || [];

              return (
                <li key={unit}>
                  <div className="text-blue-600 font-medium mb-1">📘 {unit} ({count}개 질문)</div>
                  <ul className="pl-4 list-disc text-sm text-gray-700">
                    {userQuestions.map((q, i) => {
                      const formattedDate = q.date
                        ? (() => {
                            const d = new Date(q.date);
                            return `(${d.getMonth() + 1}/${d.getDate()})`;
                          })()
                        : '';
                      return <li key={i}>{q.text} {formattedDate}</li>;
                    })}
                  </ul>
                </li>
              );
            })}
          </ul>
        </div>
      ))}
    </div>
  );
}
