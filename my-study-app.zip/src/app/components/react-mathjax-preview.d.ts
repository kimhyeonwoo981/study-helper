// react-mathjax-preview.d.ts
declare module 'react-mathjax-preview';
