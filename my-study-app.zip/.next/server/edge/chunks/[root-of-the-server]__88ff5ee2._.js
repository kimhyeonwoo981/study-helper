(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["chunks/[root-of-the-server]__88ff5ee2._.js", {

"[externals]/node:buffer [external] (node:buffer, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:buffer", () => require("node:buffer"));

module.exports = mod;
}}),
"[externals]/node:async_hooks [external] (node:async_hooks, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("node:async_hooks", () => require("node:async_hooks"));

module.exports = mod;
}}),
"[project]/src/app/api/chat-stream/route.ts [app-edge-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// src/app/api/chat-stream/route.ts
__turbopack_context__.s({
    "POST": (()=>POST),
    "runtime": (()=>runtime)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$api$2f$server$2e$js__$5b$app$2d$edge$2d$route$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/next/dist/esm/api/server.js [app-edge-route] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$spec$2d$extension$2f$response$2e$js__$5b$app$2d$edge$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/esm/server/web/spec-extension/response.js [app-edge-route] (ecmascript)");
;
const runtime = 'edge'; // ✅ Vercel 기준 streaming엔 edge runtime 필수
async function POST(req) {
    const { messages } = await req.json();
    const encoder = new TextEncoder();
    const decoder = new TextDecoder();
    const stream = new ReadableStream({
        async start (controller) {
            const res = await fetch('https://api.openai.com/v1/chat/completions', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${process.env.OPENAI_API_KEY}`
                },
                body: JSON.stringify({
                    model: 'gpt-3.5-turbo',
                    stream: true,
                    messages
                })
            });
            const reader = res.body?.getReader();
            if (!reader) {
                controller.error('Failed to read GPT stream');
                return;
            }
            const read = async ()=>{
                const { done, value } = await reader.read();
                if (done) {
                    controller.close();
                    return;
                }
                const chunk = decoder.decode(value);
                const lines = chunk.split('\n').filter((line)=>line.trim().startsWith('data: ')).map((line)=>line.replace('data: ', ''));
                for (const line of lines){
                    if (line === '[DONE]') {
                        controller.close();
                        return;
                    }
                    try {
                        const json = JSON.parse(line);
                        const text = json.choices?.[0]?.delta?.content;
                        if (text) {
                            controller.enqueue(encoder.encode(text));
                        }
                    } catch (err) {
                        controller.error(err);
                    }
                }
                await read();
            };
            await read();
        }
    });
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$spec$2d$extension$2f$response$2e$js__$5b$app$2d$edge$2d$route$5d$__$28$ecmascript$29$__["NextResponse"](stream);
}
}}),
}]);

//# sourceMappingURL=%5Broot-of-the-server%5D__88ff5ee2._.js.map