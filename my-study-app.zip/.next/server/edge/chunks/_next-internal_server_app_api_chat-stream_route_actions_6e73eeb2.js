(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["chunks/_next-internal_server_app_api_chat-stream_route_actions_6e73eeb2.js", {

"[project]/.next-internal/server/app/api/chat-stream/route/actions.js [app-edge-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
}]);

//# sourceMappingURL=_next-internal_server_app_api_chat-stream_route_actions_6e73eeb2.js.map