(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_e3f6079e._.js",
  "static/chunks/src_app_calendar_page_tsx_d64d2ab5._.js",
  "static/chunks/node_modules_react-calendar_dist_Calendar_47db48d4.css"
],
    source: "dynamic"
});
