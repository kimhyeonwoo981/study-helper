(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_react-calendar_dist_esm_bca2d744._.js",
  "static/chunks/node_modules_lodash_20634561._.js",
  "static/chunks/node_modules_recharts_es6_46c96339._.js",
  "static/chunks/node_modules_73d260ad._.js",
  "static/chunks/src_app_page_tsx_b025fed5._.js",
  "static/chunks/node_modules_react-calendar_dist_Calendar_47db48d4.css"
],
    source: "dynamic"
});
